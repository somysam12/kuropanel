<?php

$servername = "localhost";
$username = "ranaoptr_gangster";
$password = "ranaoptr_gangster";
$dbname = "ranaoptr_gangster";

$conn = mysqli_connect($servername,$username,$password,$dbname);

if(!$conn) {

die(" PROBLEM WITH CONNECTION : " . mysqli_connect_error());

}
  
?>

// JOIN MORE UPDATES @ONLINE_KURO_PANEL //